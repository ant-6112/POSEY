import webview
import os
import sys

def get_dist_dir():
    """
    Returns the path to the 'dist' directory.
    Handles the case where the app is bundled into an executable by PyInstaller.
    """
    if getattr(sys, 'frozen', False):
        # Running in a PyInstaller bundle
        return os.path.join(sys._MEIPASS, 'dist')
    else:
        # Running in a normal Python environment
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dist')

def main():
    dist_dir = get_dist_dir()
    index_file = os.path.join(dist_dir, 'index.html')

    if not os.path.exists(index_file):
        print(f"Error: Could not find {index_file}.")
        print("Please run 'npm run build' to generate the React build files first.")
        sys.exit(1)

    # Create a native window that loads the local index.html file
    # pywebview automatically hosts local files via a built-in HTTP server
    window = webview.create_window(
        'Wiki Link Game', 
        url=index_file, 
        width=1200, 
        height=800,
        min_size=(800, 600)
    )
    
    # Start the webview loop
    webview.start()

if __name__ == '__main__':
    main()
