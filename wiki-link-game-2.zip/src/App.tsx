/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Setup } from './components/Setup';
import { Game } from './components/Game';
import { GamePair, GameStatus } from './types';

export default function App() {
  const [status, setStatus] = useState<GameStatus>('setup');
  const [currentPair, setCurrentPair] = useState<GamePair | null>(null);
  const [timerDuration, setTimerDuration] = useState<number>(180);

  const handleStartGame = (pair: GamePair, duration: number) => {
    setCurrentPair(pair);
    setTimerDuration(duration);
    setStatus('playing');
  };

  const handleEndGame = (result: 'won' | 'lost') => {
    setStatus(result);
  };

  const handlePlayAgain = () => {
    setStatus('setup');
    setCurrentPair(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      {status === 'setup' && (
        <Setup onStart={handleStartGame} />
      )}
      {(status === 'playing' || status === 'won' || status === 'lost') && currentPair && (
        <Game
          pair={currentPair}
          duration={timerDuration}
          status={status}
          onEnd={handleEndGame}
          onPlayAgain={handlePlayAgain}
        />
      )}
    </div>
  );
}
