import React, { useState, useEffect } from 'react';
import { GamePair, GameStatus } from '../types';
import { WikiRenderer } from './WikiRenderer';
import { Clock, Flag, RotateCcw, ChevronRight, Trophy, XCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface GameProps {
  pair: GamePair;
  duration: number;
  status: GameStatus;
  onEnd: (result: 'won' | 'lost') => void;
  onPlayAgain: () => void;
}

export const Game: React.FC<GameProps> = ({ pair, duration, status, onEnd, onPlayAgain }) => {
  const [currentArticle, setCurrentArticle] = useState(pair.start);
  const [path, setPath] = useState<string[]>([]);
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    if (status !== 'playing') return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onEnd('lost');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [status, onEnd]);

  const handleNavigate = (article: string) => {
    if (status !== 'playing') return;
    setCurrentArticle(article);
  };

  const handleArticleLoad = (title: string) => {
    if (status !== 'playing') return;

    setPath((prev) => {
      const newPath = [...prev, title];
      return newPath;
    });

    // Check win condition
    if (title.toLowerCase() === pair.target.toLowerCase()) {
      onEnd('won');
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-white">
      {/* Header */}
      <header className="bg-gray-900 text-white p-4 shadow-md z-10 flex-shrink-0">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3 text-lg">
            <span className="font-semibold text-gray-300">{pair.start}</span>
            <ChevronRight className="w-5 h-5 text-gray-500" />
            <span className="font-bold text-blue-400 text-xl">{pair.target}</span>
          </div>

          <div className="flex items-center gap-6">
            <div className={`flex items-center gap-2 font-mono text-xl ${timeLeft < 30 ? 'text-red-400 animate-pulse' : 'text-white'}`}>
              <Clock className="w-5 h-5" />
              {formatTime(timeLeft)}
            </div>
            <div className="flex items-center gap-2 text-gray-300">
              <Flag className="w-5 h-5" />
              <span>{path.length} clicks</span>
            </div>
            {status === 'playing' && (
              <button
                onClick={() => onEnd('lost')}
                className="text-sm bg-gray-800 hover:bg-gray-700 px-3 py-1.5 rounded-lg transition-colors"
              >
                Give Up
              </button>
            )}
          </div>
        </div>
        {/* Path Breadcrumbs */}
        <div className="max-w-6xl mx-auto mt-3 overflow-x-auto whitespace-nowrap pb-2 scrollbar-hide">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            {path.map((p, i) => (
              <React.Fragment key={i}>
                <span className={i === path.length - 1 ? 'text-white font-medium' : ''}>{p}</span>
                {i < path.length - 1 && <ChevronRight className="w-3 h-3" />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto relative bg-gray-50">
        <div className="max-w-4xl mx-auto bg-white min-h-full p-8 shadow-sm">
          <WikiRenderer
            article={currentArticle}
            onNavigate={handleNavigate}
            onLoad={handleArticleLoad}
            disabled={status !== 'playing'}
          />
        </div>

        {/* End Game Overlay */}
        {status !== 'playing' && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center"
            >
              {status === 'won' ? (
                <>
                  <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Trophy className="w-10 h-10" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">You Won!</h2>
                  <p className="text-gray-600 mb-6">
                    You reached <strong className="text-gray-900">{pair.target}</strong> in {path.length} clicks with {formatTime(timeLeft)} remaining.
                  </p>
                </>
              ) : (
                <>
                  <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <XCircle className="w-10 h-10" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">Time's Up!</h2>
                  <p className="text-gray-600 mb-6">
                    You didn't reach <strong className="text-gray-900">{pair.target}</strong> in time.
                  </p>
                </>
              )}

              <div className="bg-gray-50 rounded-xl p-4 mb-8 text-left max-h-48 overflow-y-auto">
                <h3 className="font-semibold text-gray-900 mb-2 text-sm uppercase tracking-wider">Your Path:</h3>
                <div className="flex flex-wrap gap-2">
                  {path.map((p, i) => (
                    <React.Fragment key={i}>
                      <span className="text-sm text-gray-700">{p}</span>
                      {i < path.length - 1 && <span className="text-gray-400">→</span>}
                    </React.Fragment>
                  ))}
                </div>
              </div>

              <button
                onClick={onPlayAgain}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-5 h-5" />
                Play Again
              </button>
            </motion.div>
          </div>
        )}
      </main>
    </div>
  );
};
