import React, { useEffect, useState, useRef } from 'react';

interface WikiRendererProps {
  article: string;
  onNavigate: (article: string) => void;
  onLoad: (title: string) => void;
  disabled?: boolean;
}

export const WikiRenderer: React.FC<WikiRendererProps> = ({ article, onNavigate, onLoad, disabled }) => {
  const [html, setHtml] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let isMounted = true;
    const fetchPage = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`https://en.wikipedia.org/w/api.php?action=parse&page=${encodeURIComponent(article)}&format=json&origin=*&redirects=1&prop=text|displaytitle`);
        const data = await res.json();
        if (data.error) {
          throw new Error(data.error.info);
        }
        if (isMounted) {
          // Replace relative protocol URLs with https to avoid broken images
          let contentHtml = data.parse.text['*'];
          contentHtml = contentHtml.replace(/src="\/\//g, 'src="https://');
          contentHtml = contentHtml.replace(/srcset="\/\//g, 'srcset="https://');

          setHtml(contentHtml);
          onLoad(data.parse.title);

          // Scroll to top on new article load
          if (containerRef.current) {
            containerRef.current.scrollIntoView({ behavior: 'smooth' });
          }
        }
      } catch (err: any) {
        if (isMounted) setError(err.message || 'Failed to load article');
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    fetchPage();
    return () => { isMounted = false; };
  }, [article]);

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (disabled) {
      e.preventDefault();
      return;
    }

    const target = e.target as HTMLElement;
    const anchor = target.closest('a');
    if (!anchor) return;

    e.preventDefault();

    const href = anchor.getAttribute('href');
    if (href && href.startsWith('/wiki/')) {
      const articleName = href.split('/wiki/')[1];

      // Ignore special namespaces
      if (articleName.includes(':')) {
         const namespace = articleName.split(':')[0];
         const allowedNamespaces = ['Category'];
         if (!allowedNamespaces.includes(namespace)) {
             return;
         }
      }

      // Remove hash for clean navigation
      const cleanName = articleName.split('#')[0];
      if (cleanName) {
        onNavigate(decodeURIComponent(cleanName));
      }
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-4"></div>
        <p className="text-gray-500 font-medium">Loading Wikipedia article...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-6 rounded-xl border border-red-100 text-center">
        <h3 className="font-bold text-lg mb-2">Error Loading Article</h3>
        <p>{error}</p>
        <button
          onClick={() => onNavigate(article)}
          className="mt-4 bg-red-100 text-red-700 px-4 py-2 rounded-lg font-medium hover:bg-red-200 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="wiki-content"
      onClick={handleClick}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};
