import React, { useState, useEffect } from 'react';
import { GamePair } from '../types';
import { Clock, Shuffle } from 'lucide-react';
import { WORD_LIST } from '../wordList';

interface SetupProps {
  onStart: (pair: GamePair, duration: number) => void;
}

export const Setup: React.FC<SetupProps> = ({ onStart }) => {
  const [duration, setDuration] = useState<number>(() => {
    const saved = localStorage.getItem('wiki-duration');
    return saved ? parseInt(saved, 10) : 180;
  });

  useEffect(() => {
    localStorage.setItem('wiki-duration', duration.toString());
  }, [duration]);

  const handleStartRandom = () => {
    // Pick 2 random distinct words
    const shuffled = [...WORD_LIST].sort(() => 0.5 - Math.random());
    const start = shuffled[0];
    const target = shuffled[1];

    onStart({
      id: Date.now().toString(),
      start,
      target
    }, duration);
  };

  return (
    <div className="max-w-3xl mx-auto p-6 pt-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 mb-4">Wiki Link Game</h1>
        <p className="text-lg text-gray-600">Navigate from a random start word to a random target word using only Wikipedia links.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8 max-w-md mx-auto">
        <div className="p-6 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Game Settings</h2>
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-gray-500" />
            <select
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value, 10))}
              className="bg-white border border-gray-300 rounded-lg px-3 py-1.5 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={60}>1 Minute</option>
              <option value={120}>2 Minutes</option>
              <option value={180}>3 Minutes</option>
              <option value={300}>5 Minutes</option>
              <option value={600}>10 Minutes</option>
            </select>
          </div>
        </div>

        <div className="p-8 flex flex-col items-center justify-center">
          <button
            onClick={handleStartRandom}
            className="w-full bg-blue-600 text-white py-4 rounded-xl font-semibold text-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-3 shadow-md hover:shadow-lg"
          >
            <Shuffle className="w-6 h-6" />
            Play Random Words
          </button>
          <p className="mt-4 text-sm text-gray-500 text-center">
            We'll pick 2 random words from our curated list.
          </p>
        </div>
      </div>
    </div>
  );
};
