export interface GamePair {
  id: string;
  start: string;
  target: string;
}

export type GameStatus = 'setup' | 'playing' | 'won' | 'lost';
