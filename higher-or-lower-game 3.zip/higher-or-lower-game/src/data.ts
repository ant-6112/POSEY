export type CategoryItem = {
  name: string;
  value: number;
  imageUrl?: string;
};

export type Category = {
  id: string;
  name: string;
  unit: string;
  prefix?: string;
  items: CategoryItem[];
};

export const categories: Category[] = [
  {
    id: "calories",
    name: "Calories",
    unit: "Calories",
    items: [
      {
        name: "Samosa",
        value: 260,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Samosa-and-Chatni.jpg/1280px-Samosa-and-Chatni.jpg",
      },
      {
        name: "Pizza (1 slice)",
        value: 285,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Pizza-3007395.jpg/1280px-Pizza-3007395.jpg",
      },
      {
        name: "Burger",
        value: 295,
        imageUrl:
          "https://image.pollinations.ai/prompt/Burger%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Butter Chicken (1 cup)",
        value: 400,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Butter_Chicken_%26_Butter_Naan_-_Home_-_Chandigarh_-_India_-_0006.jpg/1280px-Butter_Chicken_%26_Butter_Naan_-_Home_-_Chandigarh_-_India_-_0006.jpg",
      },
      {
        name: "Masala Dosa",
        value: 160,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Rameshwaram_Cafe_Dosa.jpg/1280px-Rameshwaram_Cafe_Dosa.jpg",
      },
      {
        name: "French Fries (medium)",
        value: 365,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/French_Fries.JPG/500px-French_Fries.JPG",
      },
      {
        name: "Gulab Jamun (2 pcs)",
        value: 300,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Bowl_of_Gulab_Jamuns.jpg/1280px-Bowl_of_Gulab_Jamuns.jpg",
      },
      {
        name: "Apple (1 medium)",
        value: 95,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Pink_lady_and_cross_section.jpg/1280px-Pink_lady_and_cross_section.jpg",
      },
      {
        name: "Chocolate Bar (50g)",
        value: 260,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Green_and_Black%27s_dark_chocolate_bar_2.jpg/1280px-Green_and_Black%27s_dark_chocolate_bar_2.jpg",
      },
      {
        name: "Biryani (1 plate)",
        value: 500,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/%22Hyderabadi_Dum_Biryani%22.jpg/1280px-%22Hyderabadi_Dum_Biryani%22.jpg",
      },
      {
        name: "Vada Pav",
        value: 300,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Vada_Pav-Indian_street_food.JPG/1280px-Vada_Pav-Indian_street_food.JPG",
      },
      {
        name: "Salad (no dressing)",
        value: 50,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Salad_platter.jpg/1280px-Salad_platter.jpg",
      },
      {
        name: "Ice Cream (1 scoop)",
        value: 140,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Ice_cream_with_whipped_cream%2C_chocolate_syrup%2C_and_a_wafer_%28cropped%29.jpg/1280px-Ice_cream_with_whipped_cream%2C_chocolate_syrup%2C_and_a_wafer_%28cropped%29.jpg",
      },
      {
        name: "Paneer Tikka (1 plate)",
        value: 260,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Paneer_tikka.jpg/1280px-Paneer_tikka.jpg",
      },
      {
        name: "Chole Bhature (1 plate)",
        value: 450,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Chole_Bhature_from_Nagpur.JPG/1280px-Chole_Bhature_from_Nagpur.JPG",
      },
      {
        name: "Pasta (1 plate)",
        value: 350,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/%28Pasta%29_by_David_Adam_Kess_%28pic.2%29.jpg/1280px-%28Pasta%29_by_David_Adam_Kess_%28pic.2%29.jpg",
      },
      {
        name: "Cheesecake (1 slice)",
        value: 400,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Baked_cheesecake_with_raspberries_and_blueberries.jpg/1280px-Baked_cheesecake_with_raspberries_and_blueberries.jpg",
      },
      {
        name: "Jalebi (100g)",
        value: 300,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Basavanagudi_Kadalekai_Parishe_%282025%29_Bangalore_%2886%29.jpg/1280px-Basavanagudi_Kadalekai_Parishe_%282025%29_Bangalore_%2886%29.jpg",
      },
      {
        name: "Momos (steamed, 6 pcs)",
        value: 150,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Momo_nepal.jpg/1280px-Momo_nepal.jpg",
      },
      {
        name: "Tacos (2 pcs)",
        value: 350,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/001_Tacos_de_carnitas%2C_carne_asada_y_al_pastor.jpg/1280px-001_Tacos_de_carnitas%2C_carne_asada_y_al_pastor.jpg",
      },
      {
        name: "Donut",
        value: 250,
        imageUrl:
          "https://image.pollinations.ai/prompt/Donut%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Croissant",
        value: 230,
        imageUrl:
          "https://image.pollinations.ai/prompt/Croissant%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Sushi Roll",
        value: 200,
        imageUrl:
          "https://image.pollinations.ai/prompt/Sushi%20Roll%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Chicken Tikka Masala",
        value: 350,
        imageUrl:
          "https://image.pollinations.ai/prompt/Chicken%20Tikka%20Masala%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Naan",
        value: 260,
        imageUrl:
          "https://image.pollinations.ai/prompt/Naan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Tandoori Chicken",
        value: 275,
        imageUrl:
          "https://image.pollinations.ai/prompt/Tandoori%20Chicken%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Pad Thai",
        value: 400,
        imageUrl:
          "https://image.pollinations.ai/prompt/Pad%20Thai%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Ramen",
        value: 450,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ramen%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Taco",
        value: 150,
        imageUrl:
          "https://image.pollinations.ai/prompt/Taco%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Burrito",
        value: 500,
        imageUrl:
          "https://image.pollinations.ai/prompt/Burrito%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "market-cap",
    name: "Market Cap",
    prefix: "$",
    unit: "Billion",
    items: [
      {
        name: "Apple",
        value: 3000,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Pink_lady_and_cross_section.jpg/1280px-Pink_lady_and_cross_section.jpg",
      },
      {
        name: "Microsoft",
        value: 3100,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Aerial_Microsoft_West_Campus_August_2009.jpg/1280px-Aerial_Microsoft_West_Campus_August_2009.jpg",
      },
      {
        name: "HDFC Bank",
        value: 150,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/EXCON_2025%2C_Bangalore_International_Exhibition_Centre_%28396%29.jpg/1280px-EXCON_2025%2C_Bangalore_International_Exhibition_Centre_%28396%29.jpg",
      },
      {
        name: "ICICI Bank",
        value: 100,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Icici-bandra_kurla_complex.jpg/1280px-Icici-bandra_kurla_complex.jpg",
      },
      {
        name: "State Bank of India (SBI)",
        value: 90,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/State_Bank_of_India_Corporate_Centre_Mumbai.jpg/1280px-State_Bank_of_India_Corporate_Centre_Mumbai.jpg",
      },
      {
        name: "Reliance Industries",
        value: 250,
        imageUrl:
          "https://image.pollinations.ai/prompt/Reliance%20Industries%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Tata Consultancy Services (TCS)",
        value: 170,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/TCS_SIPCOT_Building.jpg/1280px-TCS_SIPCOT_Building.jpg",
      },
      {
        name: "JPMorgan Chase",
        value: 550,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/270parkave_from_empirestate_03_14_2025_%28cropped%29.jpg/1280px-270parkave_from_empirestate_03_14_2025_%28cropped%29.jpg",
      },
      {
        name: "Bank of America",
        value: 280,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Bank_of_America_Corporate_Center.jpg/1280px-Bank_of_America_Corporate_Center.jpg",
      },
      {
        name: "Kotak Mahindra Bank",
        value: 45,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kotak%20Mahindra%20Bank%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Axis Bank",
        value: 40,
        imageUrl:
          "https://image.pollinations.ai/prompt/Axis%20Bank%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Alphabet (Google)",
        value: 2000,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Phoenician_alphabet.svg/1280px-Phoenician_alphabet.svg.png",
      },
      {
        name: "Amazon",
        value: 1800,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Amazon_Tower_I_topped_out%2C_June_2015.jpg/1280px-Amazon_Tower_I_topped_out%2C_June_2015.jpg",
      },
      {
        name: "Meta",
        value: 1200,
        imageUrl:
          "https://image.pollinations.ai/prompt/Meta%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Tesla",
        value: 600,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Tesla_circa_1890.jpeg/500px-Tesla_circa_1890.jpeg",
      },
      {
        name: "Infosys",
        value: 80,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Infosys_%284911287704%29.jpg/1280px-Infosys_%284911287704%29.jpg",
      },
      {
        name: "Bajaj Finance",
        value: 50,
        imageUrl:
          "https://image.pollinations.ai/prompt/Bajaj%20Finance%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Wells Fargo",
        value: 200,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Wells_Fargo_Logo_%282020%29.svg/1280px-Wells_Fargo_Logo_%282020%29.svg.png",
      },
      {
        name: "Citigroup",
        value: 110,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Citi_logo_March_2023.svg/1280px-Citi_logo_March_2023.svg.png",
      },
      {
        name: "HSBC",
        value: 160,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/8-Canada-Square_%28cropped%29.jpg/500px-8-Canada-Square_%28cropped%29.jpg",
      },
      {
        name: "Nvidia",
        value: 2200,
        imageUrl:
          "https://image.pollinations.ai/prompt/Nvidia%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Berkshire Hathaway",
        value: 850,
        imageUrl:
          "https://image.pollinations.ai/prompt/Berkshire%20Hathaway%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Eli Lilly",
        value: 700,
        imageUrl:
          "https://image.pollinations.ai/prompt/Eli%20Lilly%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "TSMC",
        value: 600,
        imageUrl:
          "https://image.pollinations.ai/prompt/TSMC%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Broadcom",
        value: 600,
        imageUrl:
          "https://image.pollinations.ai/prompt/Broadcom%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Visa",
        value: 550,
        imageUrl:
          "https://image.pollinations.ai/prompt/Visa%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Novo Nordisk",
        value: 550,
        imageUrl:
          "https://image.pollinations.ai/prompt/Novo%20Nordisk%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Walmart",
        value: 500,
        imageUrl:
          "https://image.pollinations.ai/prompt/Walmart%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Mastercard",
        value: 450,
        imageUrl:
          "https://image.pollinations.ai/prompt/Mastercard%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "LVMH",
        value: 400,
        imageUrl:
          "https://image.pollinations.ai/prompt/LVMH%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "net-worth",
    name: "Net Worth (Indians)",
    prefix: "$",
    unit: "Billion",
    items: [
      {
        name: "Mukesh Ambani",
        value: 115,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Mukesh_Ambani.jpg/250px-Mukesh_Ambani.jpg",
      },
      {
        name: "Gautam Adani",
        value: 80,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Gautam_Adani.jpg/330px-Gautam_Adani.jpg",
      },
      {
        name: "Shiv Nadar",
        value: 35,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/Shiv_Nadar.png/500px-Shiv_Nadar.png",
      },
      {
        name: "Savitri Jindal",
        value: 30,
        imageUrl:
          "https://image.pollinations.ai/prompt/Savitri%20Jindal%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Cyrus Poonawalla",
        value: 25,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/The_Union_Minister_for_Finance%2C_Corporate_Affairs_and_Information_%26_Broadcasting%2C_Shri_Arun_Jaitley_felicitating_Dr._Cyrus_Poonawalla%2C_at_the_Iranshah_Udvada_Utsav%2C_in_Udvada%2C_Gujarat_on_December_27%2C_2015.jpg/1280px-thumbnail.jpg",
      },
      {
        name: "Dilip Shanghvi",
        value: 20,
        imageUrl:
          "https://image.pollinations.ai/prompt/Dilip%20Shanghvi%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kumar Birla",
        value: 18,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Kumar_Mangalam_Birla.jpg/500px-Kumar_Mangalam_Birla.jpg",
      },
      {
        name: "Radhakishan Damani",
        value: 17,
        imageUrl:
          "https://image.pollinations.ai/prompt/Radhakishan%20Damani%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Lakshmi Mittal",
        value: 16,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Lakshmi_Mittal_LM.jpg/330px-Lakshmi_Mittal_LM.jpg",
      },
      {
        name: "Uday Kotak",
        value: 14,
        imageUrl:
          "https://image.pollinations.ai/prompt/Uday%20Kotak%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Azim Premji",
        value: 11,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Azim_H._Premji_World_Economic_Forum_2013.jpg/1280px-Azim_H._Premji_World_Economic_Forum_2013.jpg",
      },
      {
        name: "Sunil Mittal",
        value: 10,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/Sunil_Mittal.jpg/330px-Sunil_Mittal.jpg",
      },
      {
        name: "Anand Mahindra",
        value: 3,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Anand_Mahindra_%281%29.jpg/500px-Anand_Mahindra_%281%29.jpg",
      },
      {
        name: "N. R. Narayana Murthy",
        value: 4.5,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Narayana_Murthy_CIF_%28cropped%29.JPG/500px-Narayana_Murthy_CIF_%28cropped%29.JPG",
      },
      {
        name: "Nandan Nilekani",
        value: 3.5,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Nandan_M._Nilekani.jpg/500px-Nandan_M._Nilekani.jpg",
      },
      {
        name: "Rekha Jhunjhunwala",
        value: 8,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Shri_Rakesh_Radheyshyam_Jhunjhunwala.jpg/960px-Shri_Rakesh_Radheyshyam_Jhunjhunwala.jpg",
      },
      {
        name: "Falguni Nayar",
        value: 3,
        imageUrl:
          "https://image.pollinations.ai/prompt/Falguni%20Nayar%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Vijay Shekhar Sharma",
        value: 1,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Vijay_Shekhar_Sharma_%282019%29.jpg/500px-Vijay_Shekhar_Sharma_%282019%29.jpg",
      },
      {
        name: "Kiran Mazumdar-Shaw",
        value: 2.5,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Kiran_Mazumdar-Shaw_HD2014_crop.jpg/1280px-Kiran_Mazumdar-Shaw_HD2014_crop.jpg",
      },
      {
        name: "Ravi Ruia",
        value: 3.2,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ravi%20Ruia%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Shapoor Mistry",
        value: 30,
        imageUrl:
          "https://image.pollinations.ai/prompt/Shapoor%20Mistry%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Benu Gopal Bangur",
        value: 8,
        imageUrl:
          "https://image.pollinations.ai/prompt/Benu%20Gopal%20Bangur%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kushal Pal Singh",
        value: 15,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kushal%20Pal%20Singh%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kalanithi Maran",
        value: 3,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kalanithi%20Maran%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Pankaj Patel",
        value: 7,
        imageUrl:
          "https://image.pollinations.ai/prompt/Pankaj%20Patel%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Sudhir Mehta",
        value: 6,
        imageUrl:
          "https://image.pollinations.ai/prompt/Sudhir%20Mehta%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Ravi Jaipuria",
        value: 11,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ravi%20Jaipuria%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Ashwin Dani",
        value: 7,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ashwin%20Dani%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "websites",
    name: "Websites",
    unit: "Billion Monthly Visits",
    items: [
      {
        name: "Google.com",
        value: 85,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Googleplex_HQ_%28cropped%29.jpg/1280px-Googleplex_HQ_%28cropped%29.jpg",
      },
      {
        name: "YouTube.com",
        value: 33,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Youtube_interface%2C_showing_search_results_of_Burger_Recipe.png/1280px-Youtube_interface%2C_showing_search_results_of_Burger_Recipe.png",
      },
      {
        name: "Facebook.com",
        value: 17,
        imageUrl:
          "https://image.pollinations.ai/prompt/Facebook.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Instagram.com",
        value: 7,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1280px-Instagram_logo_2022.svg.png",
      },
      {
        name: "Twitter.com (X)",
        value: 6,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/X_%28formerly_Twitter%29_logo_late_2025.svg/1280px-X_%28formerly_Twitter%29_logo_late_2025.svg.png",
      },
      {
        name: "Wikipedia.org",
        value: 4.5,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/8/80/Wikipedia-logo-v2.svg/1280px-Wikipedia-logo-v2.svg.png",
      },
      {
        name: "Yahoo.com",
        value: 3.5,
        imageUrl:
          "https://image.pollinations.ai/prompt/Yahoo.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Amazon.com",
        value: 2.5,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Amazon_Tower_I_topped_out%2C_June_2015.jpg/1280px-Amazon_Tower_I_topped_out%2C_June_2015.jpg",
      },
      {
        name: "WhatsApp.com",
        value: 3,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/WhatsApp_Logo_green.svg/1280px-WhatsApp_Logo_green.svg.png",
      },
      {
        name: "Netflix.com",
        value: 1.5,
        imageUrl:
          "https://image.pollinations.ai/prompt/Netflix.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Reddit.com",
        value: 2,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/6/6a/Old_reddit%2C_2025.png/1280px-Old_reddit%2C_2025.png",
      },
      {
        name: "LinkedIn.com",
        value: 1.7,
        imageUrl:
          "https://image.pollinations.ai/prompt/LinkedIn.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Office.com",
        value: 1.6,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/West_side_of_Manhattan_from_Hudson_Commons_%2895103p%29.jpg/1280px-West_side_of_Manhattan_from_Hudson_Commons_%2895103p%29.jpg",
      },
      {
        name: "Bing.com",
        value: 1.3,
        imageUrl:
          "https://image.pollinations.ai/prompt/Bing.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Twitch.tv",
        value: 1.2,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Twitch_logo_2019.svg/1280px-Twitch_logo_2019.svg.png",
      },
      {
        name: "Pinterest.com",
        value: 1.1,
        imageUrl:
          "https://image.pollinations.ai/prompt/Pinterest.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Weather.com",
        value: 1,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Port_and_lighthouse_overnight_storm_with_lightning_in_Port-la-Nouvelle.jpg/1280px-Port_and_lighthouse_overnight_storm_with_lightning_in_Port-la-Nouvelle.jpg",
      },
      {
        name: "Zoom.us",
        value: 0.9,
        imageUrl:
          "https://image.pollinations.ai/prompt/Zoom.us%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Quora.com",
        value: 0.8,
        imageUrl:
          "https://image.pollinations.ai/prompt/Quora.com%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "eBay.com",
        value: 0.7,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/EBay_logo.svg/1280px-EBay_logo.svg.png",
      },
      {
        name: "TikTok",
        value: 2,
        imageUrl:
          "https://image.pollinations.ai/prompt/TikTok%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "OpenAI",
        value: 1.5,
        imageUrl:
          "https://image.pollinations.ai/prompt/OpenAI%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Discord",
        value: 1,
        imageUrl:
          "https://image.pollinations.ai/prompt/Discord%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Bing",
        value: 1.3,
        imageUrl:
          "https://image.pollinations.ai/prompt/Bing%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Live",
        value: 1.8,
        imageUrl:
          "https://image.pollinations.ai/prompt/Live%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Microsoft",
        value: 1,
        imageUrl:
          "https://image.pollinations.ai/prompt/Microsoft%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Apple",
        value: 0.8,
        imageUrl:
          "https://image.pollinations.ai/prompt/Apple%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "cricket-runs",
    name: "Cricket Runs Edition",
    unit: "ODI Runs",
    items: [
      {
        name: "Sachin Tendulkar",
        value: 18426,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Sachin_Tendulkar_family_%28cropped%29.jpg/60px-Sachin_Tendulkar_family_%28cropped%29.jpg",
      },
      {
        name: "Kumar Sangakkara",
        value: 14234,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Kumar_Sangakkara_bat_in_hand.JPG/1280px-Kumar_Sangakkara_bat_in_hand.JPG",
      },
      {
        name: "Ricky Ponting",
        value: 13704,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/Ricky_Ponting_2015.jpg/500px-Ricky_Ponting_2015.jpg",
      },
      {
        name: "Sanath Jayasuriya",
        value: 13430,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Sanath_jayasuriya_portrait.jpg/250px-Sanath_jayasuriya_portrait.jpg",
      },
      {
        name: "Virat Kohli",
        value: 13848,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Virat_Kohli_in_PMO_New_Delhi.jpg/500px-Virat_Kohli_in_PMO_New_Delhi.jpg",
      },
      {
        name: "Mahela Jayawardene",
        value: 12650,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Mahela_Jayawardene_3.JPG/1280px-Mahela_Jayawardene_3.JPG",
      },
      {
        name: "Inzamam-ul-Haq",
        value: 11739,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Inzamam-ul-Haq.jpg/500px-Inzamam-ul-Haq.jpg",
      },
      {
        name: "Jacques Kallis",
        value: 11579,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Jacques_Kallis_6.jpg/500px-Jacques_Kallis_6.jpg",
      },
      {
        name: "Sourav Ganguly",
        value: 11363,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Sourav_Ganguly_%28late_2010s%29.jpg/500px-Sourav_Ganguly_%28late_2010s%29.jpg",
      },
      {
        name: "Rahul Dravid",
        value: 10889,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Rahul_Dravid_in_2024.jpg/330px-Rahul_Dravid_in_2024.jpg",
      },
      {
        name: "MS Dhoni",
        value: 10773,
        imageUrl:
          "https://image.pollinations.ai/prompt/MS%20Dhoni%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Brian Lara",
        value: 10405,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Brian_Lara_at_2012_Mumbai_Marathon_pre_bash.jpg/250px-Brian_Lara_at_2012_Mumbai_Marathon_pre_bash.jpg",
      },
      {
        name: "Rohit Sharma",
        value: 10709,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Prime_Minister_Of_Bharat_Shri_Narendra_Damodardas_Modi_with_Shri_Rohit_Gurunath_Sharma_%28Cropped%29.jpg/500px-Prime_Minister_Of_Bharat_Shri_Narendra_Damodardas_Modi_with_Shri_Rohit_Gurunath_Sharma_%28Cropped%29.jpg",
      },
      {
        name: "Tillakaratne Dilshan",
        value: 10290,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Tillakaratne_Dilshan_portrait.jpg/500px-Tillakaratne_Dilshan_portrait.jpg",
      },
      {
        name: "Mohammad Yousuf",
        value: 9720,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Mohammad_yousuf.jpg/500px-Mohammad_yousuf.jpg",
      },
      {
        name: "Adam Gilchrist",
        value: 9619,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Adam_Gilchrist_of_Australia_%28cropped%29.jpg/500px-Adam_Gilchrist_of_Australia_%28cropped%29.jpg",
      },
      {
        name: "AB de Villiers",
        value: 9577,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/AB_de_villiers_%28cropped%29.jpg/500px-AB_de_villiers_%28cropped%29.jpg",
      },
      {
        name: "Chris Gayle",
        value: 10480,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Two_views_of_Chris_Gayle_%2848020785077%29.jpg/1280px-Two_views_of_Chris_Gayle_%2848020785077%29.jpg",
      },
      {
        name: "Saeed Anwar",
        value: 8824,
        imageUrl:
          "https://image.pollinations.ai/prompt/Saeed%20Anwar%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Hashim Amla",
        value: 8113,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/HASHIM_AMLA_%283175887080%29.jpg/1280px-HASHIM_AMLA_%283175887080%29.jpg",
      },
      {
        name: "Stephen Fleming",
        value: 8037,
        imageUrl:
          "https://image.pollinations.ai/prompt/Stephen%20Fleming%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Herschelle Gibbs",
        value: 8094,
        imageUrl:
          "https://image.pollinations.ai/prompt/Herschelle%20Gibbs%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Michael Clarke",
        value: 7981,
        imageUrl:
          "https://image.pollinations.ai/prompt/Michael%20Clarke%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Ross Taylor",
        value: 8607,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ross%20Taylor%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Eoin Morgan",
        value: 7701,
        imageUrl:
          "https://image.pollinations.ai/prompt/Eoin%20Morgan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Tamim Iqbal",
        value: 8357,
        imageUrl:
          "https://image.pollinations.ai/prompt/Tamim%20Iqbal%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Mushfiqur Rahim",
        value: 7792,
        imageUrl:
          "https://image.pollinations.ai/prompt/Mushfiqur%20Rahim%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Shoaib Malik",
        value: 7534,
        imageUrl:
          "https://image.pollinations.ai/prompt/Shoaib%20Malik%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "cricket-wickets",
    name: "Cricket Wickets Edition",
    unit: "ODI Wickets",
    items: [
      {
        name: "Muttiah Muralitharan",
        value: 534,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Photograph_of_Muttiah_Muralitharan.jpg/330px-Photograph_of_Muttiah_Muralitharan.jpg",
      },
      {
        name: "Wasim Akram",
        value: 502,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f4/Wasim-akram-gesf-2018-7878.jpg/1280px-Wasim-akram-gesf-2018-7878.jpg",
      },
      {
        name: "Waqar Younis",
        value: 416,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Pakistan_Super_League_PSLt20_Cricket_-_Waqar_Yonus_%28cropped%29.png/120px-Pakistan_Super_League_PSLt20_Cricket_-_Waqar_Yonus_%28cropped%29.png",
      },
      {
        name: "Chaminda Vaas",
        value: 400,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Chaminda_Vaas.jpg/500px-Chaminda_Vaas.jpg",
      },
      {
        name: "Shahid Afridi",
        value: 395,
        imageUrl:
          "https://image.pollinations.ai/prompt/Shahid%20Afridi%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Shaun Pollock",
        value: 393,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Shaun_Pollock.JPG/120px-Shaun_Pollock.JPG",
      },
      {
        name: "Glenn McGrath",
        value: 381,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Glenn_McGrath_Portrait%2C_2011%2C_jjron.jpg/960px-Glenn_McGrath_Portrait%2C_2011%2C_jjron.jpg",
      },
      {
        name: "Brett Lee",
        value: 380,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Brett_lee_closeup2.jpg/330px-Brett_lee_closeup2.jpg",
      },
      {
        name: "Lasith Malinga",
        value: 338,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Lasith_Malinga_tossing_a_cricket_ball_at_practice.jpg/1280px-Lasith_Malinga_tossing_a_cricket_ball_at_practice.jpg",
      },
      {
        name: "Anil Kumble",
        value: 337,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/d/de/Anil_Kumble_%281%29.jpg",
      },
      {
        name: "Sanath Jayasuriya",
        value: 323,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Sanath_jayasuriya_portrait.jpg/250px-Sanath_jayasuriya_portrait.jpg",
      },
      {
        name: "Javagal Srinath",
        value: 315,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Javagal_Srinath_%28Feb%2C_2023%29.jpg/500px-Javagal_Srinath_%28Feb%2C_2023%29.jpg",
      },
      {
        name: "Daniel Vettori",
        value: 305,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/5/54/Daniel_Vettori_ONZM_%28cropped%29.jpg/500px-Daniel_Vettori_ONZM_%28cropped%29.jpg",
      },
      {
        name: "Zaheer Khan",
        value: 282,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Zaheer_Khan_at_the_CPAA_show_2018_%28cropped%29.jpg/120px-Zaheer_Khan_at_the_CPAA_show_2018_%28cropped%29.jpg",
      },
      {
        name: "Ajit Agarkar",
        value: 288,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/AjitAgarkar.jpg/250px-AjitAgarkar.jpg",
      },
      {
        name: "Shakib Al Hasan",
        value: 317,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Shakib_Al_Hasan_%284%29_%28cropped%29.jpg/1280px-Shakib_Al_Hasan_%284%29_%28cropped%29.jpg",
      },
      {
        name: "Mitchell Starc",
        value: 236,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Mitchell_Starc_2023.jpg/330px-Mitchell_Starc_2023.jpg",
      },
      {
        name: "Trent Boult",
        value: 211,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/2018.02.03.22.23.14-AUSvNZL_T20_AUS_innings%2C_SCG_%2839533156665%29.jpg/1280px-2018.02.03.22.23.14-AUSvNZL_T20_AUS_innings%2C_SCG_%2839533156665%29.jpg",
      },
      {
        name: "Jasprit Bumrah",
        value: 149,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/Jasprit_Bumrah_in_PMO_New_Delhi.jpg/500px-Jasprit_Bumrah_in_PMO_New_Delhi.jpg",
      },
      {
        name: "Mohammed Shami",
        value: 195,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Mohammed_Shami_Arjuna_Award_%28cropped%29.jpg/500px-Mohammed_Shami_Arjuna_Award_%28cropped%29.jpg",
      },
      {
        name: "Imran Khan",
        value: 182,
        imageUrl:
          "https://image.pollinations.ai/prompt/Imran%20Khan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kapil Dev",
        value: 253,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kapil%20Dev%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Courtney Walsh",
        value: 227,
        imageUrl:
          "https://image.pollinations.ai/prompt/Courtney%20Walsh%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Curtly Ambrose",
        value: 225,
        imageUrl:
          "https://image.pollinations.ai/prompt/Curtly%20Ambrose%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Allan Donald",
        value: 272,
        imageUrl:
          "https://image.pollinations.ai/prompt/Allan%20Donald%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Makhaya Ntini",
        value: 266,
        imageUrl:
          "https://image.pollinations.ai/prompt/Makhaya%20Ntini%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Saqlain Mushtaq",
        value: 288,
        imageUrl:
          "https://image.pollinations.ai/prompt/Saqlain%20Mushtaq%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Harbhajan Singh",
        value: 269,
        imageUrl:
          "https://image.pollinations.ai/prompt/Harbhajan%20Singh%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "movies",
    name: "Movies",
    prefix: "â¹",
    unit: "Crores (Box Office)",
    items: [
      {
        name: "Dangal",
        value: 2000,
        imageUrl:
          "https://image.pollinations.ai/prompt/Dangal%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Baahubali 2: The Conclusion",
        value: 1810,
        imageUrl:
          "https://image.pollinations.ai/prompt/Baahubali%202%3A%20The%20Conclusion%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "RRR",
        value: 1300,
        imageUrl:
          "https://image.pollinations.ai/prompt/RRR%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "K.G.F: Chapter 2",
        value: 1200,
        imageUrl:
          "https://image.pollinations.ai/prompt/K.G.F%3A%20Chapter%202%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Jawan",
        value: 1140,
        imageUrl:
          "https://image.pollinations.ai/prompt/Jawan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Pathaan",
        value: 1050,
        imageUrl:
          "https://image.pollinations.ai/prompt/Pathaan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Bajrangi Bhaijaan",
        value: 969,
        imageUrl:
          "https://image.pollinations.ai/prompt/Bajrangi%20Bhaijaan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Animal",
        value: 915,
        imageUrl:
          "https://image.pollinations.ai/prompt/Animal%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Secret Superstar",
        value: 900,
        imageUrl:
          "https://image.pollinations.ai/prompt/Secret%20Superstar%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "PK",
        value: 830,
        imageUrl:
          "https://image.pollinations.ai/prompt/PK%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "2.0",
        value: 800,
        imageUrl:
          "https://image.pollinations.ai/prompt/2.0%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Baahubali: The Beginning",
        value: 650,
        imageUrl:
          "https://image.pollinations.ai/prompt/Baahubali%3A%20The%20Beginning%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Sultan",
        value: 623,
        imageUrl:
          "https://image.pollinations.ai/prompt/Sultan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Sanju",
        value: 586,
        imageUrl:
          "https://image.pollinations.ai/prompt/Sanju%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Padmaavat",
        value: 585,
        imageUrl:
          "https://image.pollinations.ai/prompt/Padmaavat%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Tiger Zinda Hai",
        value: 565,
        imageUrl:
          "https://image.pollinations.ai/prompt/Tiger%20Zinda%20Hai%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Dhoom 3",
        value: 556,
        imageUrl:
          "https://image.pollinations.ai/prompt/Dhoom%203%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "War",
        value: 475,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Hawai_Mare_oki_kaisen_poster.jpg/330px-Hawai_Mare_oki_kaisen_poster.jpg",
      },
      {
        name: "3 Idiots",
        value: 460,
        imageUrl:
          "https://image.pollinations.ai/prompt/3%20Idiots%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Pushpa: The Rise",
        value: 350,
        imageUrl:
          "https://image.pollinations.ai/prompt/Pushpa%3A%20The%20Rise%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Krrish 3",
        value: 393,
        imageUrl:
          "https://image.pollinations.ai/prompt/Krrish%203%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kick",
        value: 402,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kick%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Chennai Express",
        value: 423,
        imageUrl:
          "https://image.pollinations.ai/prompt/Chennai%20Express%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Prem Ratan Dhan Payo",
        value: 432,
        imageUrl:
          "https://image.pollinations.ai/prompt/Prem%20Ratan%20Dhan%20Payo%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Happy New Year",
        value: 397,
        imageUrl:
          "https://image.pollinations.ai/prompt/Happy%20New%20Year%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Ek Tha Tiger",
        value: 334,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ek%20Tha%20Tiger%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Yeh Jawaani Hai Deewani",
        value: 319,
        imageUrl:
          "https://image.pollinations.ai/prompt/Yeh%20Jawaani%20Hai%20Deewani%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Brahmastra",
        value: 431,
        imageUrl:
          "https://image.pollinations.ai/prompt/Brahmastra%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "amazon",
    name: "Amazon (Indian Edition)",
    prefix: "â¹",
    unit: "",
    items: [
      {
        name: "iPhone 15 Pro Max",
        value: 159900,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/IPhone_15_Pro_Vector.svg/1280px-IPhone_15_Pro_Vector.svg.png",
      },
      {
        name: "Sony PlayStation 5",
        value: 54990,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Black_and_white_Playstation_5_base_edition_with_controller.png/1280px-Black_and_white_Playstation_5_base_edition_with_controller.png",
      },
      {
        name: "Apple AirPods Pro (2nd Gen)",
        value: 24900,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/AirPods_Pro_%282nd_generation%29.jpg/1280px-AirPods_Pro_%282nd_generation%29.jpg",
      },
      {
        name: "Kindle Paperwhite",
        value: 13999,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Amazon_Kindle_2024.svg/1280px-Amazon_Kindle_2024.svg.png",
      },
      {
        name: "Echo Dot (4th Gen)",
        value: 3999,
        imageUrl:
          "https://image.pollinations.ai/prompt/Echo%20Dot%20(4th%20Gen)%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Samsung Galaxy S24 Ultra",
        value: 129999,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Samsung_Galaxy_S24%2C_Sperrbildschirm.JPG/1280px-Samsung_Galaxy_S24%2C_Sperrbildschirm.JPG",
      },
      {
        name: "OnePlus 12",
        value: 64999,
        imageUrl:
          "https://image.pollinations.ai/prompt/OnePlus%2012%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Dell XPS 15",
        value: 250000,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/DELL_XPS_13_and_15_%2837080596413%29.jpg/1280px-DELL_XPS_13_and_15_%2837080596413%29.jpg",
      },
      {
        name: "MacBook Air M2",
        value: 114900,
        imageUrl:
          "https://image.pollinations.ai/prompt/MacBook%20Air%20M2%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Sony WH-1000XM5 Headphones",
        value: 29990,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/DSEE_logo.png/500px-DSEE_logo.png",
      },
      {
        name: "Dyson V11 Absolute Pro",
        value: 52900,
        imageUrl:
          "https://image.pollinations.ai/prompt/Dyson%20V11%20Absolute%20Pro%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Mi Smart Band 8",
        value: 2499,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Xiaomi_Mi_Band_8.jpg/1280px-Xiaomi_Mi_Band_8.jpg",
      },
      {
        name: "Logitech MX Master 3S",
        value: 10995,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Logitech_Unifying_Receiver_USB.jpg/1280px-Logitech_Unifying_Receiver_USB.jpg",
      },
      {
        name: "LG 55 inch 4K Smart OLED TV",
        value: 139990,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/OEL_right.JPG/1280px-OEL_right.JPG",
      },
      {
        name: "Bajaj Chetak Electric Scooter",
        value: 115000,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Bajaj_Chetak_150.JPG/1280px-Bajaj_Chetak_150.JPG",
      },
      {
        name: "Royal Enfield Classic 350 (Scale Model)",
        value: 1500,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Royal_Enfield_Classic_350_%282017_Model_Year%29.jpg/1280px-Royal_Enfield_Classic_350_%282017_Model_Year%29.jpg",
      },
      {
        name: "Milton Thermosteel Flask (1L)",
        value: 950,
        imageUrl:
          "https://image.pollinations.ai/prompt/Milton%20Thermosteel%20Flask%20(1L)%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Pigeon by Stovekraft Air Fryer",
        value: 2999,
        imageUrl:
          "https://image.pollinations.ai/prompt/Pigeon%20by%20Stovekraft%20Air%20Fryer%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Boat Airdopes 141",
        value: 1299,
        imageUrl:
          "https://image.pollinations.ai/prompt/Boat%20Airdopes%20141%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Fastrack Reflex Smartwatch",
        value: 1995,
        imageUrl:
          "https://image.pollinations.ai/prompt/Fastrack%20Reflex%20Smartwatch%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "iPad Air",
        value: 59900,
        imageUrl:
          "https://image.pollinations.ai/prompt/iPad%20Air%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Samsung Galaxy Watch 6",
        value: 29999,
        imageUrl:
          "https://image.pollinations.ai/prompt/Samsung%20Galaxy%20Watch%206%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "HP Pavilion Laptop",
        value: 65000,
        imageUrl:
          "https://image.pollinations.ai/prompt/HP%20Pavilion%20Laptop%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Sony Alpha ILCE-6400L",
        value: 75000,
        imageUrl:
          "https://image.pollinations.ai/prompt/Sony%20Alpha%20ILCE-6400L%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "GoPro HERO12",
        value: 39000,
        imageUrl:
          "https://image.pollinations.ai/prompt/GoPro%20HERO12%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "DJI Mini 3 Drone",
        value: 45000,
        imageUrl:
          "https://image.pollinations.ai/prompt/DJI%20Mini%203%20Drone%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "LG 1.5 Ton AC",
        value: 40000,
        imageUrl:
          "https://image.pollinations.ai/prompt/LG%201.5%20Ton%20AC%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "IFB Washing Machine",
        value: 35000,
        imageUrl:
          "https://image.pollinations.ai/prompt/IFB%20Washing%20Machine%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "travel",
    name: "Travel",
    unit: "Million Visitors/Year",
    items: [
      {
        name: "Bangkok",
        value: 22,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/Bangkok_Montage_2024_2.jpg/1280px-Bangkok_Montage_2024_2.jpg",
      },
      {
        name: "Paris",
        value: 19,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/La_Tour_Eiffel_vue_de_la_Tour_Saint-Jacques%2C_Paris_ao%C3%BBt_2014_%282%29.jpg/1280px-La_Tour_Eiffel_vue_de_la_Tour_Saint-Jacques%2C_Paris_ao%C3%BBt_2014_%282%29.jpg",
      },
      {
        name: "London",
        value: 19,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/London_Skyline_%28125508655%29.jpeg/1280px-London_Skyline_%28125508655%29.jpeg",
      },
      {
        name: "Dubai",
        value: 16,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/c/c7/Burj_Khalifa_2021.jpg/1280px-Burj_Khalifa_2021.jpg",
      },
      {
        name: "Singapore",
        value: 14,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Flag_of_Singapore.svg/1280px-Flag_of_Singapore.svg.png",
      },
      {
        name: "Kuala Lumpur",
        value: 13,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Bukit_Bintang_junction_in_2024_2.jpg/1280px-Bukit_Bintang_junction_in_2024_2.jpg",
      },
      {
        name: "New York City",
        value: 13,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/View_of_Empire_State_Building_from_Rockefeller_Center_New_York_City_dllu_%28cropped%29.jpg/1280px-View_of_Empire_State_Building_from_Rockefeller_Center_New_York_City_dllu_%28cropped%29.jpg",
      },
      {
        name: "Istanbul",
        value: 13,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Historical_peninsula_and_modern_skyline_of_Istanbul.jpg/1280px-Historical_peninsula_and_modern_skyline_of_Istanbul.jpg",
      },
      {
        name: "Tokyo",
        value: 10,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Skyscrapers_of_Shinjuku_2009_January.jpg/1280px-Skyscrapers_of_Shinjuku_2009_January.jpg",
      },
      {
        name: "Antalya",
        value: 12,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Falezlerden_Antalya_Konyaalt%C4%B1_Plaj%C4%B1na_do%C4%9Fru_bir_g%C3%B6r%C3%BCn%C3%BCm.jpg/1280px-Falezlerden_Antalya_Konyaalt%C4%B1_Plaj%C4%B1na_do%C4%9Fru_bir_g%C3%B6r%C3%BCn%C3%BCm.jpg",
      },
      {
        name: "Seoul",
        value: 9,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/%EC%A4%91%ED%99%94%EC%A0%84%EC%9D%98_%EB%82%AE.jpg/1280px-%EC%A4%91%ED%99%94%EC%A0%84%EC%9D%98_%EB%82%AE.jpg",
      },
      {
        name: "Osaka",
        value: 8,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Osaka_Castle_03bs3200.jpg/1280px-Osaka_Castle_03bs3200.jpg",
      },
      {
        name: "Makkah",
        value: 8,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Great_Mosque_of_Mecca1.jpg/1280px-Great_Mosque_of_Mecca1.jpg",
      },
      {
        name: "Phuket",
        value: 9,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Phuket_Aerial.jpg/1280px-Phuket_Aerial.jpg",
      },
      {
        name: "Pattaya",
        value: 8,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Pattaya_beach_from_view_point.jpg/1280px-Pattaya_beach_from_view_point.jpg",
      },
      {
        name: "Milan",
        value: 6,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Milan_skyline_skyscrapers_of_Porta_Nuova_business_district_%28cropped%29.jpg/1280px-Milan_skyline_skyscrapers_of_Porta_Nuova_business_district_%28cropped%29.jpg",
      },
      {
        name: "Barcelona",
        value: 9,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Aerial_view_of_Barcelona%2C_Spain_%2851227309370%29_edited.jpg/1280px-Aerial_view_of_Barcelona%2C_Spain_%2851227309370%29_edited.jpg",
      },
      {
        name: "Palma de Mallorca",
        value: 8,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Kathedrale_von_Palma.jpg/1280px-Kathedrale_von_Palma.jpg",
      },
      {
        name: "Bali",
        value: 6,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Bali_in_Indonesia_%28special_marker%29.svg/1280px-Bali_in_Indonesia_%28special_marker%29.svg.png",
      },
      {
        name: "Hong Kong",
        value: 15,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Flag_of_Hong_Kong.svg/1280px-Flag_of_Hong_Kong.svg.png",
      },
      {
        name: "Rome",
        value: 10,
        imageUrl:
          "https://image.pollinations.ai/prompt/Rome%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Prague",
        value: 9,
        imageUrl:
          "https://image.pollinations.ai/prompt/Prague%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Amsterdam",
        value: 8,
        imageUrl:
          "https://image.pollinations.ai/prompt/Amsterdam%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Vienna",
        value: 7,
        imageUrl:
          "https://image.pollinations.ai/prompt/Vienna%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Venice",
        value: 6,
        imageUrl:
          "https://image.pollinations.ai/prompt/Venice%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Madrid",
        value: 6,
        imageUrl:
          "https://image.pollinations.ai/prompt/Madrid%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Berlin",
        value: 5,
        imageUrl:
          "https://image.pollinations.ai/prompt/Berlin%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Athens",
        value: 5,
        imageUrl:
          "https://image.pollinations.ai/prompt/Athens%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "football",
    name: "Football",
    unit: "International Goals",
    items: [
      {
        name: "Cristiano Ronaldo",
        value: 128,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Cristiano_Ronaldo_2275_%28cropped%29.jpg/1280px-Cristiano_Ronaldo_2275_%28cropped%29.jpg",
      },
      {
        name: "Lionel Messi",
        value: 106,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Lionel_Messi_NE_Revolution_Inter_Miami_7.9.25-178.jpg/1280px-Lionel_Messi_NE_Revolution_Inter_Miami_7.9.25-178.jpg",
      },
      {
        name: "Ali Daei",
        value: 109,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Ali_Daei%2C_Saipa_vs._Al-Rayyan_pre-match_conference.jpg/500px-Ali_Daei%2C_Saipa_vs._Al-Rayyan_pre-match_conference.jpg",
      },
      {
        name: "Sunil Chhetri",
        value: 94,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/The_President%2C_Shri_Ram_Nath_Kovind_presenting_the_Major_Dhyan_Chand_Khel_Ratna_Award%2C_2021_to_Shri_Sunil_Chhetri_for_Football%2C_at_Rashtrapati_Bhavan%2C_in_New_Delhi_on_13_November_2021_%28cropped%29.jpg/500px-thumbnail.jpg",
      },
      {
        name: "Mokhtar Dahari",
        value: 89,
        imageUrl:
          "https://image.pollinations.ai/prompt/Mokhtar%20Dahari%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Ferenc PuskÃ¡s",
        value: 84,
        imageUrl:
          "https://image.pollinations.ai/prompt/Ferenc%20Pusk%C3%83%C2%A1s%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Robert Lewandowski",
        value: 82,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/2019147183134_2019-05-27_Fussball_1.FC_Kaiserslautern_vs_FC_Bayern_M%C3%BCnchen_-_Sven_-_1D_X_MK_II_-_0228_-_B70I8527_%28cropped%29.jpg/1280px-2019147183134_2019-05-27_Fussball_1.FC_Kaiserslautern_vs_FC_Bayern_M%C3%BCnchen_-_Sven_-_1D_X_MK_II_-_0228_-_B70I8527_%28cropped%29.jpg",
      },
      {
        name: "Neymar",
        value: 79,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Neymar_Jr._with_Al_Hilal%2C_3_October_2023_-_03_%28cropped%29.jpg/330px-Neymar_Jr._with_Al_Hilal%2C_3_October_2023_-_03_%28cropped%29.jpg",
      },
      {
        name: "Romelu Lukaku",
        value: 83,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Romelu_Lukaku_2021.jpg/500px-Romelu_Lukaku_2021.jpg",
      },
      {
        name: "PelÃ©",
        value: 77,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Aegeansea.jpg/500px-Aegeansea.jpg",
      },
      {
        name: "SÃ¡ndor Kocsis",
        value: 75,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Kocsis_S%C3%A1ndor_Fortepan_261526.jpg/1280px-Kocsis_S%C3%A1ndor_Fortepan_261526.jpg",
      },
      {
        name: "Miroslav Klose",
        value: 71,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/2016209185719_2016-07-27_Champions_for_Charity_-_Sven_-_1D_X_-_0149_-_DV3P4742_mod.jpg/1280px-2016209185719_2016-07-27_Champions_for_Charity_-_Sven_-_1D_X_-_0149_-_DV3P4742_mod.jpg",
      },
      {
        name: "Luis SuÃ¡rez",
        value: 68,
        imageUrl:
          "https://image.pollinations.ai/prompt/Luis%20Su%C3%83%C2%A1rez%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Harry Kane",
        value: 62,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Harry_Kane_on_October_10%2C_2023.jpg/500px-Harry_Kane_on_October_10%2C_2023.jpg",
      },
      {
        name: "Zlatan IbrahimoviÄ",
        value: 62,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Zlatan_Ibrahimovi%C4%87_June_2018.jpg/330px-Zlatan_Ibrahimovi%C4%87_June_2018.jpg",
      },
      {
        name: "David Villa",
        value: 59,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Spain-Tahiti%2C_Confederations_Cup_2013_%2802%29_%28Villa_crop%29.jpg/330px-Spain-Tahiti%2C_Confederations_Cup_2013_%2802%29_%28Villa_crop%29.jpg",
      },
      {
        name: "Edin DÅ¾eko",
        value: 65,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Sido_-_2020170220237_2020-06-18_Sido_-_Sven_-_1D_X_MK_II_-_0193_-_B70I4096.jpg/1280px-Sido_-_2020170220237_2020-06-18_Sido_-_Sven_-_1D_X_MK_II_-_0193_-_B70I4096.jpg",
      },
      {
        name: "Olivier Giroud",
        value: 56,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Olivier_Giroud_December_2024.png/120px-Olivier_Giroud_December_2024.png",
      },
      {
        name: "Wayne Rooney",
        value: 53,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Wayne_Rooney_%2850121495731%29_%28cropped%29.jpg/500px-Wayne_Rooney_%2850121495731%29_%28cropped%29.jpg",
      },
      {
        name: "Kylian MbappÃ©",
        value: 46,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kylian%20Mbapp%C3%83%C2%A9%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kunishige Kamamoto",
        value: 75,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kunishige%20Kamamoto%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Bashar Abdullah",
        value: 75,
        imageUrl:
          "https://image.pollinations.ai/prompt/Bashar%20Abdullah%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Majed Abdullah",
        value: 72,
        imageUrl:
          "https://image.pollinations.ai/prompt/Majed%20Abdullah%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kinnah Phiri",
        value: 71,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kinnah%20Phiri%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Stern John",
        value: 70,
        imageUrl:
          "https://image.pollinations.ai/prompt/Stern%20John%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Hossam Hassan",
        value: 68,
        imageUrl:
          "https://image.pollinations.ai/prompt/Hossam%20Hassan%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Carlos Ruiz",
        value: 68,
        imageUrl:
          "https://image.pollinations.ai/prompt/Carlos%20Ruiz%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Robbie Keane",
        value: 68,
        imageUrl:
          "https://image.pollinations.ai/prompt/Robbie%20Keane%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
  {
    id: "countries-population",
    name: "Countries Population",
    unit: "Million People",
    items: [
      {
        name: "India",
        value: 1428,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/1280px-Flag_of_India.svg.png",
      },
      {
        name: "China",
        value: 1425,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/1280px-Flag_of_the_People%27s_Republic_of_China.svg.png",
      },
      {
        name: "United States",
        value: 340,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Flag_of_the_United_States_%28DDD-F-416E_specifications%29.svg/1280px-Flag_of_the_United_States_%28DDD-F-416E_specifications%29.svg.png",
      },
      {
        name: "Indonesia",
        value: 278,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Flag_of_Indonesia.svg/1280px-Flag_of_Indonesia.svg.png",
      },
      {
        name: "Pakistan",
        value: 240,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Flag_of_Pakistan.svg/1280px-Flag_of_Pakistan.svg.png",
      },
      {
        name: "Nigeria",
        value: 224,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Flag_of_Nigeria.svg/1280px-Flag_of_Nigeria.svg.png",
      },
      {
        name: "Brazil",
        value: 216,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/0/05/Flag_of_Brazil.svg/1280px-Flag_of_Brazil.svg.png",
      },
      {
        name: "Bangladesh",
        value: 173,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Flag_of_Bangladesh.svg/1280px-Flag_of_Bangladesh.svg.png",
      },
      {
        name: "Russia",
        value: 144,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/f/f3/Flag_of_Russia.svg/1280px-Flag_of_Russia.svg.png",
      },
      {
        name: "Mexico",
        value: 128,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Flag_of_Mexico.svg/1280px-Flag_of_Mexico.svg.png",
      },
      {
        name: "Ethiopia",
        value: 126,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Flag_of_Ethiopia.svg/1280px-Flag_of_Ethiopia.svg.png",
      },
      {
        name: "Japan",
        value: 123,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/9/9e/Flag_of_Japan.svg/1280px-Flag_of_Japan.svg.png",
      },
      {
        name: "Philippines",
        value: 117,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Flag_of_the_Philippines.svg/1280px-Flag_of_the_Philippines.svg.png",
      },
      {
        name: "Egypt",
        value: 112,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Flag_of_Egypt.svg/1280px-Flag_of_Egypt.svg.png",
      },
      {
        name: "DR Congo",
        value: 102,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Flag_of_the_Democratic_Republic_of_the_Congo.svg/1280px-Flag_of_the_Democratic_Republic_of_the_Congo.svg.png",
      },
      {
        name: "Vietnam",
        value: 98,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Flag_of_Vietnam.svg/1280px-Flag_of_Vietnam.svg.png",
      },
      {
        name: "Iran",
        value: 89,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Flag_of_Iran_%28official%29.svg/1280px-Flag_of_Iran_%28official%29.svg.png",
      },
      {
        name: "Turkey",
        value: 85,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Flag_of_Turkey.svg/1280px-Flag_of_Turkey.svg.png",
      },
      {
        name: "Germany",
        value: 83,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/en/thumb/b/ba/Flag_of_Germany.svg/1280px-Flag_of_Germany.svg.png",
      },
      {
        name: "United Kingdom",
        value: 67,
        imageUrl:
          "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Flag_of_the_United_Kingdom_%281-2%29.svg/1280px-Flag_of_the_United_Kingdom_%281-2%29.svg.png",
      },
      {
        name: "South Africa",
        value: 60,
        imageUrl:
          "https://image.pollinations.ai/prompt/South%20Africa%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Tanzania",
        value: 67,
        imageUrl:
          "https://image.pollinations.ai/prompt/Tanzania%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "France",
        value: 68,
        imageUrl:
          "https://image.pollinations.ai/prompt/France%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Italy",
        value: 59,
        imageUrl:
          "https://image.pollinations.ai/prompt/Italy%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Myanmar",
        value: 54,
        imageUrl:
          "https://image.pollinations.ai/prompt/Myanmar%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Kenya",
        value: 55,
        imageUrl:
          "https://image.pollinations.ai/prompt/Kenya%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "Colombia",
        value: 52,
        imageUrl:
          "https://image.pollinations.ai/prompt/Colombia%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
      {
        name: "South Korea",
        value: 51,
        imageUrl:
          "https://image.pollinations.ai/prompt/South%20Korea%20high%20quality%20photography?width=1080&height=1080&nologo=true",
      },
    ],
  },
];
