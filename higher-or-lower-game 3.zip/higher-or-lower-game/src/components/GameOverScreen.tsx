import React from 'react';
import { motion } from 'motion/react';
import { RotateCcw, Home, Trophy } from 'lucide-react';

type GameOverScreenProps = {
  score: number;
  highScore: number;
  player: string;
  categoryName: string;
  onRestart: () => void;
  onMenu: () => void;
};

export function GameOverScreen({
  score,
  highScore,
  player,
  categoryName,
  onRestart,
  onMenu,
}: GameOverScreenProps) {
  const isNewHighScore = score > highScore && score > 0;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="min-h-screen flex items-center justify-center p-6 bg-zinc-950"
    >
      <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-rose-500/20 to-transparent pointer-events-none" />
        
        <h2 className="text-3xl font-black mb-2 font-display text-white">Game Over!</h2>
        <p className="text-zinc-400 mb-8">
          <span className="font-medium text-zinc-300">{player}</span> played{' '}
          <span className="font-medium text-zinc-300">{categoryName}</span>
        </p>

        <div className="bg-zinc-950 rounded-2xl p-6 mb-8 border border-zinc-800/50 relative">
          {isNewHighScore && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-yellow-500 text-black text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 uppercase tracking-wider">
              <Trophy className="w-3 h-3" /> New High Score!
            </div>
          )}
          
          <div className="text-zinc-500 text-sm uppercase tracking-widest font-semibold mb-2">Score</div>
          <div className="text-7xl font-black text-white mb-6 font-display">{score}</div>
          
          <div className="flex justify-between items-center pt-6 border-t border-zinc-800">
            <span className="text-zinc-400">High Score</span>
            <span className="text-xl font-bold text-zinc-200">{Math.max(score, highScore)}</span>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button
            onClick={onRestart}
            className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-5 h-5" />
            Play Again
          </button>
          <button
            onClick={onMenu}
            className="w-full bg-zinc-800 text-white font-bold py-4 rounded-xl hover:bg-zinc-700 transition-colors flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5" />
            Main Menu
          </button>
        </div>
      </div>
    </motion.div>
  );
}
