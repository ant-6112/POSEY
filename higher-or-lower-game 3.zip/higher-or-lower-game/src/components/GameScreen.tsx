import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Category, CategoryItem } from '../data';
import { shuffleArray, getRandomColor } from '../utils';
import { ArrowDown, ArrowUp, X, Check } from 'lucide-react';
import CountUp from 'react-countup';

type GameScreenProps = {
  category: Category;
  onGameOver: (score: number) => void;
};

export function GameScreen({ category, onGameOver }: GameScreenProps) {
  const [items, setItems] = useState<CategoryItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [isRevealing, setIsRevealing] = useState(false);
  const [guessResult, setGuessResult] = useState<'correct' | 'wrong' | null>(null);

  useEffect(() => {
    // Initialize game with shuffled items
    setItems(shuffleArray(category.items));
    setCurrentIndex(0);
    setScore(0);
    setIsRevealing(false);
    setGuessResult(null);
  }, [category]);

  if (items.length < 2) return null;

  const item1 = items[currentIndex];
  const item2 = items[currentIndex + 1];

  const handleGuess = (guess: 'higher' | 'lower') => {
    if (isRevealing) return;

    setIsRevealing(true);
    
    const isCorrect =
      (guess === 'higher' && item2.value >= item1.value) ||
      (guess === 'lower' && item2.value <= item1.value);

    setGuessResult(isCorrect ? 'correct' : 'wrong');

    setTimeout(() => {
      if (isCorrect) {
        setScore((s) => s + 1);
        
        // Check if we ran out of items
        if (currentIndex + 2 >= items.length) {
          // Reshuffle remaining or just end game? Let's just end for simplicity or reshuffle.
          // For now, if they beat the whole list, they win!
          onGameOver(score + 1);
        } else {
          setCurrentIndex((i) => i + 1);
          setIsRevealing(false);
          setGuessResult(null);
        }
      } else {
        onGameOver(score);
      }
    }, 2000);
  };

  const renderItem = (item: CategoryItem, isSecond: boolean) => {
    const bgGradient = getRandomColor(item.name);
    const imageUrl = item.imageUrl;
    
    return (
      <div className={`relative flex-1 flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br ${bgGradient} overflow-hidden`}>
        {imageUrl && (
          <motion.img 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1.05 }}
            transition={{ duration: 20, ease: "linear", repeat: Infinity, repeatType: "reverse" }}
            src={imageUrl} 
            alt={item.name}
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-50"
          />
        )}
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-transparent to-zinc-950/30" />
        
        <div className="relative z-10 flex flex-col items-center max-w-2xl mx-auto w-full">
          <h2 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow-lg font-display leading-tight">
            "{item.name}"
          </h2>
          <p className="text-xl md:text-2xl mb-8 opacity-90 drop-shadow-md">has</p>
          
          {(!isSecond || isRevealing) ? (
            <motion.div 
              initial={isSecond ? { scale: 0.5, opacity: 0 } : false}
              animate={{ scale: 1, opacity: 1 }}
              className="flex flex-col items-center"
            >
              <div className="text-5xl md:text-7xl font-black text-yellow-400 drop-shadow-xl mb-2 flex items-center gap-2">
                {category.prefix && <span>{category.prefix}</span>}
                {isSecond && isRevealing ? (
                  <CountUp end={item.value} duration={1.5} separator="," decimals={item.value % 1 !== 0 ? 1 : 0} />
                ) : (
                  item.value.toLocaleString()
                )}
              </div>
              <div className="text-xl md:text-2xl font-medium opacity-90 uppercase tracking-wider">
                {category.unit}
              </div>
            </motion.div>
          ) : (
            <div className="flex flex-col gap-4 w-full max-w-xs">
              <button
                onClick={() => handleGuess('higher')}
                className="group relative overflow-hidden rounded-full bg-white/10 hover:bg-white/20 border-2 border-white/50 backdrop-blur-sm transition-all py-4 px-8 flex items-center justify-center gap-3"
              >
                <ArrowUp className="w-6 h-6 text-emerald-400 group-hover:-translate-y-1 transition-transform" />
                <span className="text-2xl font-bold">Higher</span>
              </button>
              <button
                onClick={() => handleGuess('lower')}
                className="group relative overflow-hidden rounded-full bg-white/10 hover:bg-white/20 border-2 border-white/50 backdrop-blur-sm transition-all py-4 px-8 flex items-center justify-center gap-3"
              >
                <ArrowDown className="w-6 h-6 text-rose-400 group-hover:translate-y-1 transition-transform" />
                <span className="text-2xl font-bold">Lower</span>
              </button>
            </div>
          )}
        </div>

        {/* Result Overlay for the second item */}
        <AnimatePresence>
          {isSecond && isRevealing && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none"
            >
              {guessResult === 'correct' ? (
                <div className="bg-emerald-500/90 text-white rounded-full p-8 shadow-2xl backdrop-blur-md">
                  <Check className="w-24 h-24" />
                </div>
              ) : (
                <div className="bg-rose-500/90 text-white rounded-full p-8 shadow-2xl backdrop-blur-md">
                  <X className="w-24 h-24" />
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  if (!item1 || !item2) return null;

  return (
    <div className="fixed inset-0 flex flex-col md:flex-row bg-zinc-950">
      {/* Score Header */}
      <div className="absolute top-6 left-0 right-0 z-30 flex justify-center pointer-events-none">
        <div className="bg-black/50 backdrop-blur-md border border-white/10 rounded-full px-6 py-2 flex items-center gap-4 shadow-xl">
          <span className="text-zinc-400 font-medium uppercase tracking-wider text-sm">Score</span>
          <span className="text-2xl font-bold text-white">{score}</span>
        </div>
      </div>

      <AnimatePresence mode="popLayout">
        <motion.div
          key={item1.name}
          initial={{ x: '-100%' }}
          animate={{ x: 0 }}
          exit={{ x: '-100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="flex-1 flex flex-col relative"
        >
          {renderItem(item1, false)}
        </motion.div>
      </AnimatePresence>

      <AnimatePresence mode="popLayout">
        <motion.div
          key={item2.name}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="flex-1 flex flex-col relative"
        >
          {renderItem(item2, true)}
        </motion.div>
      </AnimatePresence>

      {/* VS Badge */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
        <div className="bg-white text-black w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center font-black text-xl md:text-2xl shadow-2xl shadow-black/50">
          VS
        </div>
      </div>
    </div>
  );
}
