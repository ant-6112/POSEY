import React, { useState } from 'react';
import { motion } from 'motion/react';
import { categories } from '../data';
import { Plus, User, Play, ChevronRight } from 'lucide-react';

type SetupScreenProps = {
  players: string[];
  setPlayers: (players: string[]) => void;
  currentPlayer: string;
  setCurrentPlayer: (player: string) => void;
  currentCategory: string;
  setCurrentCategory: (category: string) => void;
  onStart: () => void;
};

export function SetupScreen({
  players,
  setPlayers,
  currentPlayer,
  setCurrentPlayer,
  currentCategory,
  setCurrentCategory,
  onStart,
}: SetupScreenProps) {
  const [newPlayer, setNewPlayer] = useState('');

  const handleAddPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPlayer.trim() && !players.includes(newPlayer.trim())) {
      setPlayers([...players, newPlayer.trim()]);
      if (!currentPlayer) {
        setCurrentPlayer(newPlayer.trim());
      }
      setNewPlayer('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-4xl mx-auto p-6 min-h-screen flex flex-col"
    >
      <div className="text-center mb-12 mt-8">
        <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-4 font-display bg-gradient-to-br from-white to-zinc-500 bg-clip-text text-transparent">
          HIGHER OR LOWER
        </h1>
        <p className="text-zinc-400 text-lg">The ultimate guessing game.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 flex-1">
        {/* Players Section */}
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
              <User className="w-6 h-6 text-indigo-400" />
              1. Choose Player
            </h2>
            <p className="text-zinc-400 text-sm mb-4">Who is playing right now?</p>
          </div>

          <form onSubmit={handleAddPlayer} className="flex gap-2">
            <input
              type="text"
              value={newPlayer}
              onChange={(e) => setNewPlayer(e.target.value)}
              placeholder="Add a new player..."
              className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
            <button
              type="submit"
              disabled={!newPlayer.trim()}
              className="bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 text-white px-4 py-3 rounded-xl transition-colors flex items-center justify-center"
            >
              <Plus className="w-5 h-5" />
            </button>
          </form>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
            {players.length === 0 ? (
              <div className="text-center py-8 text-zinc-500 border border-dashed border-zinc-800 rounded-xl">
                No players added yet.
              </div>
            ) : (
              players.map((player) => (
                <button
                  key={player}
                  onClick={() => setCurrentPlayer(player)}
                  className={`w-full text-left px-4 py-3 rounded-xl transition-all flex items-center justify-between ${
                    currentPlayer === player
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                      : 'bg-zinc-900/50 hover:bg-zinc-800 text-zinc-300'
                  }`}
                >
                  <span className="font-medium">{player}</span>
                  {currentPlayer === player && <ChevronRight className="w-5 h-5" />}
                </button>
              ))
            )}
          </div>
        </div>

        {/* Categories Section */}
        <div className="space-y-6 flex flex-col">
          <div>
            <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
              <Play className="w-6 h-6 text-emerald-400" />
              2. Choose Category
            </h2>
            <p className="text-zinc-400 text-sm mb-4">What do you want to guess?</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 overflow-y-auto pr-2 custom-scrollbar flex-1 max-h-[400px]">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setCurrentCategory(category.id)}
                className={`p-4 rounded-xl text-left transition-all border ${
                  currentCategory === category.id
                    ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-100'
                    : 'bg-zinc-900/50 border-zinc-800/50 hover:bg-zinc-800 hover:border-zinc-700 text-zinc-400'
                }`}
              >
                <div className="font-semibold mb-1 text-zinc-200">{category.name}</div>
                <div className="text-xs opacity-70">{category.items.length} items</div>
              </button>
            ))}
          </div>

          <button
            onClick={onStart}
            disabled={!currentPlayer || !currentCategory}
            className="w-full bg-white text-black font-bold text-lg py-4 rounded-2xl hover:bg-zinc-200 disabled:opacity-50 disabled:hover:bg-white transition-all transform active:scale-[0.98] mt-auto"
          >
            START GAME
          </button>
        </div>
      </div>
    </motion.div>
  );
}
