import React, { useState } from 'react';
import { SetupScreen } from './components/SetupScreen';
import { GameScreen } from './components/GameScreen';
import { GameOverScreen } from './components/GameOverScreen';
import { categories } from './data';
import { useLocalStorage } from './useLocalStorage';

export default function App() {
  const [gameState, setGameState] = useState<'setup' | 'playing' | 'gameover'>('setup');
  const [players, setPlayers] = useLocalStorage<string[]>('hol-players', []);
  const [currentPlayer, setCurrentPlayer] = useState<string>('');
  const [currentCategory, setCurrentCategory] = useState<string>('');
  const [score, setScore] = useState(0);
  
  // Store high scores per category per player
  const [highScores, setHighScores] = useLocalStorage<Record<string, number>>('hol-highscores', {});

  const handleStart = () => {
    if (currentPlayer && currentCategory) {
      setGameState('playing');
    }
  };

  const handleGameOver = (finalScore: number) => {
    setScore(finalScore);
    setGameState('gameover');
    
    const scoreKey = `${currentPlayer}-${currentCategory}`;
    const currentHighScore = highScores[scoreKey] || 0;
    
    if (finalScore > currentHighScore) {
      setHighScores({
        ...highScores,
        [scoreKey]: finalScore,
      });
    }
  };

  const handleRestart = () => {
    setGameState('playing');
  };

  const handleMenu = () => {
    setGameState('setup');
  };

  const selectedCategory = categories.find((c) => c.id === currentCategory);
  const scoreKey = `${currentPlayer}-${currentCategory}`;
  const currentHighScore = highScores[scoreKey] || 0;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-50 font-sans selection:bg-indigo-500/30">
      {gameState === 'setup' && (
        <SetupScreen
          players={players}
          setPlayers={setPlayers}
          currentPlayer={currentPlayer}
          setCurrentPlayer={setCurrentPlayer}
          currentCategory={currentCategory}
          setCurrentCategory={setCurrentCategory}
          onStart={handleStart}
        />
      )}
      
      {gameState === 'playing' && selectedCategory && (
        <GameScreen
          category={selectedCategory}
          onGameOver={handleGameOver}
        />
      )}
      
      {gameState === 'gameover' && selectedCategory && (
        <GameOverScreen
          score={score}
          highScore={currentHighScore}
          player={currentPlayer}
          categoryName={selectedCategory.name}
          onRestart={handleRestart}
          onMenu={handleMenu}
        />
      )}
    </div>
  );
}
